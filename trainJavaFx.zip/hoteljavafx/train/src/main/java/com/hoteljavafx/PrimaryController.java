package com.hoteljavafx;

import java.io.IOException;
import javafx.fxml.FXML;

public class PrimaryController {

    @FXML
    private void addTrain() throws IOException {
        App.setRoot("secondary");
    }
}
