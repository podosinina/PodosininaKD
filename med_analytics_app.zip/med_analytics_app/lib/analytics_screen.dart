import 'package:flutter/material.dart';
import 'dart:html' as html;
import 'dart:typed_data';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:io' show Platform;
import 'login_screen.dart';

class AnalyticsScreen extends StatefulWidget {
  @override
  _AnalyticsScreenState createState() => _AnalyticsScreenState();
}

class _AnalyticsScreenState extends State<AnalyticsScreen> {
  String selectedReport = 'none';

  void _openReport(String reportType) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => _getReportScreen(reportType),
      ),
    );
  }

  Widget _getReportScreen(String type) {
    switch (type) {
      case 'kpi': return KPIReportScreen(onDownload: () => _downloadKPI());
      case 'daily': return DailyReportScreen(onDownload: () => _downloadDaily());
      case 'specialties': return SpecialtiesReportScreen(onDownload: () => _downloadSpecialties());
      case 'diagnosis': return DiagnosisReportScreen(onDownload: () => _downloadDiagnosis());
      case 'heatmap': return HeatmapReportScreen(onDownload: () => _downloadHeatmap());
      default: return KPIReportScreen(onDownload: () => _downloadKPI());
    }
  }

  void _downloadKPI() => _downloadTextFile('KPI_отчет.pdf', _generateKPIContent());
  void _downloadDaily() => _downloadTextFile('Динамика_отчет.pdf', _generateDailyContent());
  void _downloadSpecialties() => _downloadTextFile('Специальности_отчет.pdf', _generateSpecialtiesContent());
  void _downloadDiagnosis() => _downloadTextFile('Заболеваемость_отчет.pdf', _generateDiagnosisContent());
  void _downloadHeatmap() => _downloadTextFile('Тепловая_карта.pdf', _generateHeatmapContent());

  String _generateKPIContent() => '''
📊 KPI ОТЧЕТ
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Показатель     | Значение | Норма
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Приемы         | 1270     | 1200-1400
Средний чек    | 254      | 240-280
Загрузка       | 78.5%    | 70-85%
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Дата: ${DateTime.now().toString().split(' ')[0]}
  ''';

  String _generateDailyContent() => '''
📈 СУТОЧНАЯ ДИНАМИКА (08-14 декабря)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
200  245  267  289  312  298  292
08   09   10   11   12   13   14
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Среднее: 254 визита/сутки
Дата: ${DateTime.now().toString().split(' ')[0]}
  ''';

  String _generateSpecialtiesContent() => '''
👨‍⚕️ ЗАГРУЗКА ВРАЧЕЙ
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Терапевт: 42.5%
Хирург:   18.3%
Педиатр:  15.7%
Кардиолог:12.1%
Невролог:  8.4%
Другие:    3.0%
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Дата: ${DateTime.now().toString().split(' ')[0]}
  ''';

  String _generateDiagnosisContent() => '''
🦠 СТРУКТУРА ЗАБОЛЕВАЕМОСТИ
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ОРВИ:      27% (342)
Гипертония:15% (189)
Травмы:    12% (156)
ДГПЖ:      10% (123)
Гастрит:    8% (98)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Всего приемов: 1270
Дата: ${DateTime.now().toString().split(' ')[0]}
  ''';

  String _generateHeatmapContent() => '''
🔥 ТЕПЛОВАЯ КАРТА (неделя)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Пн Вт Ср Чт Пт Сб Вс
00-06: Низкая загрузка (зеленый)
06-12: Средняя загрузка (желтый)
12-18: Высокая загрузка (оранжевый/красный)
18-24: Пиковая загрузка (красный)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Дата: ${DateTime.now().toString().split(' ')[0]}
  ''';

  void _downloadTextFile(String filename, String content) {
    final bytes = Uint8List.fromList(utf8.encode(content));
    final blob = html.Blob([bytes], 'text/plain');
    final url = html.Url.createObjectUrlFromBlob(blob);
    final anchor = html.AnchorElement(href: url)
      ..setAttribute('download', filename)
      ..click();
    html.Url.revokeObjectUrl(url);
  }

  void _logoutToAuthPage() {
    print('🔴 ПЕРЕХОД НА СТРАНИЦУ АВТОРИЗАЦИИ');
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (context) => LoginScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('📊 Выбор отчета'),
        backgroundColor: Colors.indigo,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: () {
            Navigator.of(context).popUntil((route) => route.isFirst);
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: const Column(
                  children: [
                    Icon(Icons.analytics_outlined, size: 48, color: Colors.indigo),
                    SizedBox(height: 8),
                    Text(
                      'Выберите отчет',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 2,
                mainAxisSpacing: 2,
                childAspectRatio: 1.2,
                children: [
                  _reportCard('📊 KPI', 'kpi'),
                  _reportCard('📈 Динамика', 'daily'),
                  _reportCard('👨‍⚕️ Врачи', 'specialties'),
                  _reportCard('🦠 Диагнозы', 'diagnosis'),
                  _reportCard('🔥 Карта', 'heatmap'),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        margin: const EdgeInsets.all(16),
        child: ElevatedButton.icon(
          onPressed: _logoutToAuthPage,
          icon: const Icon(Icons.logout, color: Colors.white),
          label: const Text('Выйти из системы', style: TextStyle(color: Colors.white, fontSize: 16)),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.red,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            elevation: 4,
          ),
        ),
      ),
    );
  }

  Widget _reportCard(String title, String type) {
    return GestureDetector(
      onTap: () => _openReport(type),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: const [BoxShadow(color: Colors.grey, blurRadius: 4)],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                color: Colors.indigo.shade100,
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  title[0],
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)
                )
              ),
            ),
            const SizedBox(height: 8),
            Text(
              title,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

// ✅ ОТЧЕТЫ
class KPIReportScreen extends StatelessWidget {
  final VoidCallback onDownload;
  const KPIReportScreen({Key? key, required this.onDownload}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ReportScaffold(
      title: '📊 KPI',
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Table(
          border: TableBorder.all(color: Colors.grey, width: 1),
          defaultVerticalAlignment: TableCellVerticalAlignment.middle,
          children: [
            TableRow(
              decoration: const BoxDecoration(color: Colors.indigo),
              children: [
                _tableHeaderCell('Показатель'),
                _tableHeaderCell('Значение'),
                _tableHeaderCell('Норма'),
              ]
            ),
            TableRow(children: [
              _tableCell('Приемы'),
              _tableCell('1270'),
              _tableCell('1200-1400'),
            ]),
            TableRow(children: [
              _tableCell('Средний чек'),
              _tableCell('254'),
              _tableCell('240-280'),
            ]),
            TableRow(children: [
              _tableCell('Загрузка'),
              _tableCell('78.5%'),
              _tableCell('70-85%'),
            ]),
          ],
        ),
      ),
      onPDF: onDownload,
    );
  }

  Widget _tableCell(String text) => Padding(
    padding: const EdgeInsets.all(12),
    child: Text(text, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
  );

  Widget _tableHeaderCell(String text) => Padding(
    padding: const EdgeInsets.all(12),
    child: Text(
      text,
      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
      textAlign: TextAlign.center,
    ),
  );
}

class DailyReportScreen extends StatelessWidget {
  final VoidCallback onDownload;
  const DailyReportScreen({Key? key, required this.onDownload}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ReportScaffold(
      title: '📈 Суточная динамика',
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                const Text(
                  'Посещаемость (08-14 декабря)',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: const [
                    Text('200', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                    Text('250', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                    Text('300', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                  ],
                ),
              ],
            ),
          ),
          Container(
            height: 300,
            margin: const EdgeInsets.symmetric(horizontal: 20),
            child: CustomPaint(painter: LineChartPainter()),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: const Text(
              'Среднее: 254 визита/сутки',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)
            ),
          ),
        ],
      ),
      onPDF: onDownload,
    );
  }
}

class SpecialtiesReportScreen extends StatelessWidget {
  final VoidCallback onDownload;
  const SpecialtiesReportScreen({Key? key, required this.onDownload}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ReportScaffold(
      title: '👨‍⚕️ Загрузка врачей',
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                const Text(
                  'Загрузка по специальностям (%)',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: const [
                    Text('0%', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                    Text('25%', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                    Text('50%', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                  ],
                ),
              ],
            ),
          ),
          Container(
            height: 320,
            margin: const EdgeInsets.symmetric(horizontal: 20),
            child: CustomPaint(painter: BarChartPainter()),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: const Text(
              'Терапевт: 42.5% | Хирург: 18.3% | Педиатр: 15.7%',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)
            ),
          ),
        ],
      ),
      onPDF: onDownload,
    );
  }
}

class DiagnosisReportScreen extends StatelessWidget {
  final VoidCallback onDownload;
  const DiagnosisReportScreen({Key? key, required this.onDownload}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ReportScaffold(
      title: '🦠 Структура заболеваемости',
      child: Column(
        children: [
          const Padding(
            padding: EdgeInsets.all(20),
            child: Text(
              'Распределение диагнозов (1270 приемов)',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)
            ),
          ),
          Container(
            height: 320,
            margin: const EdgeInsets.symmetric(horizontal: 20),
            child: CustomPaint(painter: PieChartPainter()),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: const [
                LegendItem('ОРВИ', Colors.red, 27),
                LegendItem('Гипертония', Colors.orange, 15),
                LegendItem('Травмы', Colors.yellow, 12),
                LegendItem('ДГПЖ', Colors.green, 10),
                LegendItem('Гастрит', Colors.blue, 8),
              ],
            ),
          ),
        ],
      ),
      onPDF: onDownload,
    );
  }
}

class LegendItem extends StatelessWidget {
  final String text;
  final Color color;
  final int percent;

  const LegendItem(this.text, this.color, this.percent);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Container(
            width: 20,
            height: 20,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(4)
            ),
          ),
          const SizedBox(width: 12),
          Text('$text ($percent%)', style: const TextStyle(fontSize: 16)),
        ],
      ),
    );
  }
}

class HeatmapReportScreen extends StatelessWidget {
  final VoidCallback onDownload;
  const HeatmapReportScreen({Key? key, required this.onDownload}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ReportScaffold(
      title: '🔥 Тепловая карта (неделя)',
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                const Text(
                  'Загрузка по часам (Пн-Вс)',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: const [
                    Text('Низкая', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                    Text('Средняя', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                    Text('Высокая', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                  ],
                ),
              ],
            ),
          ),
          Container(
            height: 300,
            margin: const EdgeInsets.symmetric(horizontal: 20),
            child: CustomPaint(painter: HeatmapPainter()),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: const Text(
              'Пн  Вт  Ср  Чт  Пт  Сб  Вс\n00 06 12 18 00 06 12 18',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
      onPDF: onDownload,
    );
  }
}

// ✅ ✅ ✅ ИСПРАВЛЕННЫЕ ГРАФИКИ ✅ ✅ ✅
class LineChartPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // ✅ ФИКСИРОВАННЫЕ РАЗМЕРЫ: отступы для осей и подписей
    final leftMargin = 60.0;   // Ось Y + подписи
    final bottomMargin = 60.0; // Ось X + подписи
    final topMargin = 20.0;
    final chartWidth = size.width - leftMargin - 20;
    final chartHeight = size.height - topMargin - bottomMargin;

    // Сетка
    final gridPaint = Paint()
      ..color = Colors.grey.withOpacity(0.2)
      ..strokeWidth = 1;

    // Вертикальная сетка (X)
    for (int i = 0; i <= 7; i++) {
      final x = leftMargin + chartWidth * i / 7;
      canvas.drawLine(
        Offset(x, topMargin),
        Offset(x, topMargin + chartHeight),
        gridPaint
      );
    }

    // Горизонтальная сетка (Y)
    for (int i = 0; i <= 4; i++) {
      final y = topMargin + chartHeight * i / 4;
      canvas.drawLine(
        Offset(leftMargin, y),
        Offset(leftMargin + chartWidth, y),
        gridPaint
      );
    }

    // ✅ Оси координат
    final axisPaint = Paint()
      ..color = Colors.black87
      ..strokeWidth = 2;
    canvas.drawLine(
      Offset(leftMargin, topMargin),
      Offset(leftMargin, topMargin + chartHeight),
      axisPaint
    );
    canvas.drawLine(
      Offset(leftMargin, topMargin + chartHeight),
      Offset(leftMargin + chartWidth, topMargin + chartHeight),
      axisPaint
    );

    // ✅ Линия данных
    final linePaint = Paint()
      ..color = Colors.indigo
      ..strokeWidth = 4
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final data = [220, 245, 267, 289, 312, 298, 292];
    final maxY = 320.0;
    final path = Path();

    for (int i = 0; i < data.length; i++) {
      final x = leftMargin + chartWidth * i / (data.length - 1);
      final y = topMargin + chartHeight * (1 - data[i] / maxY);

      if (i == 0) path.moveTo(x, y);
      else path.lineTo(x, y);

      canvas.drawCircle(Offset(x, y), 6, Paint()..color = Colors.indigo);
    }
    canvas.drawPath(path, linePaint);

    // ✅ Подписи осей
    _drawAxisLabels(canvas, size, leftMargin, topMargin, chartWidth, chartHeight);
  }

  void _drawAxisLabels(Canvas canvas, Size size, double leftMargin, double topMargin, double chartWidth, double chartHeight) {
    // ✅ Ось Y (слева)
    final yLabels = ['200', '250', '300'];
    final maxY = 320.0;
    for (int i = 0; i < yLabels.length; i++) {
      final value = 200 + (i * 50);
      final y = topMargin + chartHeight * (1 - value / maxY);
      _drawText(canvas, yLabels[i], leftMargin - 45, y - 6, 12, Colors.black87);
    }

    // ✅ Ось X (снизу)
    final xLabels = ['08', '09', '10', '11', '12', '13', '14'];
    for (int i = 0; i < xLabels.length; i++) {
      final x = leftMargin + chartWidth * i / (xLabels.length - 1);
      _drawText(canvas, xLabels[i], x - 8, topMargin + chartHeight + 35, 12, Colors.black87);
    }
  }

  void _drawText(Canvas canvas, String text, double x, double y, double fontSize, Color color) {
    final textPainter = TextPainter(
      text: TextSpan(text: text, style: TextStyle(color: color, fontSize: fontSize, fontWeight: FontWeight.w500)),
      textDirection: TextDirection.ltr,
    );
    textPainter.layout();
    textPainter.paint(canvas, Offset(x, y));
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

class BarChartPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // ✅ ФИКСИРОВАННЫЕ РАЗМЕРЫ
    final leftMargin = 60.0;
    final bottomMargin = 60.0;
    final topMargin = 20.0;
    final chartWidth = size.width - leftMargin - 20;
    final chartHeight = size.height - topMargin - bottomMargin;

    final data = [42.5, 18.3, 15.7, 12.1, 8.4, 3.0];
    final labels = ['Тер', 'Хир', 'Пед', 'Кар', 'Нев', 'Др'];
    final colors = [Colors.teal, Colors.blue, Colors.orange, Colors.purple, Colors.green, Colors.red];
    final maxY = 50.0;

    // Сетка Y
    final gridPaint = Paint()..color = Colors.grey.withOpacity(0.2);
    for (int i = 0; i <= 4; i++) {
      final y = topMargin + chartHeight * i / 4;
      canvas.drawLine(Offset(leftMargin, y), Offset(leftMargin + chartWidth, y), gridPaint);
    }

    // Оси
    final axisPaint = Paint()..color = Colors.black87..strokeWidth = 2;
    canvas.drawLine(Offset(leftMargin, topMargin), Offset(leftMargin, topMargin + chartHeight), axisPaint);
    canvas.drawLine(Offset(leftMargin, topMargin + chartHeight), Offset(leftMargin + chartWidth, topMargin + chartHeight), axisPaint);

    // Столбцы
    final barWidth = chartWidth / data.length;
    for (int i = 0; i < data.length; i++) {
      final x = leftMargin + i * barWidth;
      final barHeight = chartHeight * data[i] / maxY;

      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(x + 8, topMargin + chartHeight - barHeight, barWidth - 16, barHeight),
          const Radius.circular(4),
        ),
        Paint()..color = colors[i],
      );

      // Подписи значений на столбцах
      _drawText(canvas, '${data[i].toStringAsFixed(1)}%', x + barWidth * 0.25, topMargin + chartHeight - barHeight - 8, 11, Colors.white);
      // Подписи X снизу
      _drawText(canvas, labels[i], x + barWidth * 0.25, topMargin + chartHeight + 35, 12, Colors.black87);
    }

    // Подписи Y
    _drawYLabels(canvas, leftMargin, topMargin, chartHeight);
  }

  void _drawText(Canvas canvas, String text, double x, double y, double fontSize, Color color) {
    final textPainter = TextPainter(
      text: TextSpan(text: text, style: TextStyle(color: color, fontSize: fontSize, fontWeight: FontWeight.bold)),
      textDirection: TextDirection.ltr,
    );
    textPainter.layout();
    textPainter.paint(canvas, Offset(x, y));
  }

  void _drawYLabels(Canvas canvas, double leftMargin, double topMargin, double chartHeight) {
    final yLabels = ['0%', '25%', '50%'];
    for (int i = 0; i < yLabels.length; i++) {
      final y = topMargin + chartHeight * (1 - i / 2.0);
      _drawText(canvas, yLabels[i], leftMargin - 45, y - 6, 12, Colors.black87);
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

class PieChartPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // ✅ ИСПРАВЛЕНА КРУГОВАЯ ДИАГРАММА - увеличен радиус и исправлена сумма данных
    final center = Offset(size.width / 2, size.height / 2 - 20);
    final radius = math.min(size.width, size.height) / 3.2; // ✅ УВЕЛИЧЕН РАДИУС

    // ✅ ИСПРАВЛЕННЫЕ ДАННЫЕ (сумма = 100%)
    final data = [27.0, 15.0, 12.0, 10.0, 8.0, 28.0]; // Проценты
    final labels = ['ОРВИ', 'Гипертония', 'Травмы', 'ДГПЖ', 'Гастрит', 'Другие'];
    final colors = [Colors.red, Colors.orange, Colors.yellow[700]!, Colors.green, Colors.blue, Colors.purple];

    double startAngle = -math.pi / 2;
    final total = data.reduce((a, b) => a + b);

    for (int i = 0; i < data.length; i++) {
      final sweepAngle = 2 * math.pi * data[i] / total;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweepAngle,
        true,
        Paint()..color = colors[i],
      );
      startAngle += sweepAngle;
    }

    // ✅ Центр диаграммы
    canvas.drawCircle(center, 30, Paint()..color = Colors.white);
    canvas.drawCircle(center, 25, Paint()..color = Colors.grey[200]!);

    // ✅ Подписи процентов по кругу
    startAngle = -math.pi / 2;
    for (int i = 0; i < data.length; i++) {
      final sweepAngle = 2 * math.pi * data[i] / total;
      final midAngle = startAngle + sweepAngle / 2;
      final labelRadius = radius + 40;
      final labelX = center.dx + math.cos(midAngle) * labelRadius;
      final labelY = center.dy + math.sin(midAngle) * labelRadius;
      _drawText(canvas, '${data[i].toStringAsFixed(0)}%', labelX - 15, labelY - 6, 12, Colors.black87);
      startAngle += sweepAngle;
    }
  }

  void _drawText(Canvas canvas, String text, double x, double y, double fontSize, Color color) {
    final textPainter = TextPainter(
      text: TextSpan(text: text, style: TextStyle(color: color, fontSize: fontSize, fontWeight: FontWeight.bold)),
      textDirection: TextDirection.ltr,
    );
    textPainter.layout();
    textPainter.paint(canvas, Offset(x, y));
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

class HeatmapPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final cellWidth = (size.width - 80) / 24;
    final cellHeight = (size.height - 120) / 7;

    // Заголовки дней (сверху)
    const days = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
    for (int day = 0; day < 7; day++) {
      _drawText(canvas, days[day], 50 + day * 45, 25, 14, Colors.black87);
    }

    // Ячейки тепловой карты
    for (int day = 0; day < 7; day++) {
      for (int hour = 0; hour < 24; hour++) {
        final load = 20 + ((hour + day * 2) % 24 * 3);
        Color color = Colors.green;
        if (load > 70) color = Colors.red;
        else if (load > 50) color = Colors.orange;
        else if (load > 30) color = Colors.yellow;

        canvas.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromLTWH(50 + hour * cellWidth, 50 + day * cellHeight, cellWidth - 1, cellHeight - 1),
            const Radius.circular(3),
          ),
          Paint()..color = color.withOpacity(0.85),
        );
      }
    }

    // Подписи часов (снизу)
    for (int h = 0; h < 24; h += 4) {
      _drawText(canvas, '$h', 52 + h * cellWidth, size.height - 30, 12, Colors.black87);
    }
  }

  void _drawText(Canvas canvas, String text, double x, double y, double fontSize, Color color) {
    final textPainter = TextPainter(
      text: TextSpan(text: text, style: TextStyle(color: color, fontSize: fontSize, fontWeight: FontWeight.bold)),
      textDirection: TextDirection.ltr,
    );
    textPainter.layout();
    textPainter.paint(canvas, Offset(x, y));
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

class ReportScaffold extends StatelessWidget {
  final String title;
  final Widget child;
  final VoidCallback onPDF;

  const ReportScaffold({
    Key? key,
    required this.title,
    required this.child,
    required this.onPDF,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        backgroundColor: Colors.indigo,
        actions: [
          IconButton(
            icon: const Icon(Icons.download),
            onPressed: onPDF,
            tooltip: 'Скачать PDF',
          ),
        ],
      ),
      body: SingleChildScrollView(child: child),
    );
  }
}
