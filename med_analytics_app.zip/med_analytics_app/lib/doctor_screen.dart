import 'package:flutter/material.dart';
import 'login_screen.dart'; // ✅ ДОБАВЛЕН ИМПОРТ LoginScreen

class DoctorScreen extends StatefulWidget {
  @override
  _DoctorScreenState createState() => _DoctorScreenState();
}

class _DoctorScreenState extends State<DoctorScreen> {
  // Тестовые данные пациентов
  List<Map<String, dynamic>> patients = [
    {
      'id': 1,
      'name': 'Иванов Иван Иванович',
      'phone': '+7 (900) 123-45-67',
      'visits': [
        {'date': '14.12.2025', 'time': '14:30', 'diagnosis': 'ОРВИ'},
        {'date': '13.12.2025', 'time': '15:15', 'diagnosis': 'Головная боль'},
      ]
    },
    {
      'id': 2,
      'name': 'Петрова Анна Сергеевна',
      'phone': '+7 (900) 987-65-43',
      'visits': [
        {'date': '14.12.2025', 'time': '16:00', 'diagnosis': 'Профилактика'},
      ]
    },
    {
      'id': 3,
      'name': 'Сидоров Петр Петрович',
      'phone': '+7 (900) 555-12-34',
      'visits': []
    },
  ];

  final _patientNameController = TextEditingController();
  final _diagnosisController = TextEditingController();
  final _timeController = TextEditingController();

  // ✅ НОВЫЙ МЕТОД ВЫХОДА (аналогично AnalyticsScreen)
  void _logoutToAuthPage() {
    print('🔴 ПЕРЕХОД НА СТРАНИЦУ АВТОРИЗАЦИИ');

    // ✅ ПРЯМАЯ НАВИГАЦИЯ К LoginScreen (очищает весь стек)
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (context) => LoginScreen()),
      (route) => false, // Удаляет все предыдущие экраны
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('👨‍⚕️ Мои пациенты', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.teal,
        elevation: 0,
      ),
      body: Column(
        children: [
          // Статистика
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.teal.shade50,
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _statCard('3', 'Пациентов', Icons.people),
                _statCard('5', 'Приемов', Icons.event),
                _statCard('4.8', 'Средний рейтинг', Icons.star),
              ],
            ),
          ),

          // Кнопка новый прием
          Padding(
            padding: EdgeInsets.all(16),
            child: ElevatedButton.icon(
              onPressed: () => _showAddVisitDialog(),
              icon: Icon(Icons.add_circle, size: 28),
              label: Text('➕ Новый прием', style: TextStyle(fontSize: 18)),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                padding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              ),
            ),
          ),

          // Список пациентов
          Expanded(
            child: ListView.builder(
              padding: EdgeInsets.symmetric(horizontal: 16),
              itemCount: patients.length,
              itemBuilder: (context, index) {
                final patient = patients[index];
                return Card(
                  margin: EdgeInsets.only(bottom: 12),
                  child: ExpansionTile(
                    leading: CircleAvatar(
                      backgroundColor: Colors.teal.shade100,
                      child: Text(patient['name'][0], style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    ),
                    title: Text(
                      patient['name'],
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text('📞 ${patient['phone']}'),
                    children: [
                      // История приемов
                      ...patient['visits'].map<Widget>((visit) => ListTile(
                            leading: Icon(Icons.medical_information, color: Colors.orange),
                            title: Text('${visit['date']} ${visit['time']}'),
                            subtitle: Text(visit['diagnosis']),
                            trailing: Icon(Icons.arrow_forward_ios, size: 16),
                          )),

                      // Кнопка новый прием для этого пациента
                      ListTile(
                        leading: Icon(Icons.add, color: Colors.green),
                        title: Text('Новый прием'),
                        trailing: Icon(Icons.chevron_right),
                        onTap: () => _showAddVisitForPatient(index),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        color: Colors.red.shade50,
        child: Padding(
          padding: EdgeInsets.all(12),
          child: ElevatedButton.icon(
            onPressed: _logoutToAuthPage, // ✅ ИСПРАВЛЕНО: теперь перекидывает на LoginScreen
            icon: Icon(Icons.logout, color: Colors.white),
            label: Text('Выход', style: TextStyle(color: Colors.white)),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            ),
          ),
        ),
      ),
    );
  }

  Widget _statCard(String value, String label, IconData icon) {
    return Column(
      children: [
        Icon(icon, size: 30, color: Colors.teal),
        SizedBox(height: 8),
        Text(value, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        Text(label, style: TextStyle(color: Colors.grey[600], fontSize: 12)),
      ],
    );
  }

  void _showAddVisitDialog() {
    _patientNameController.clear();
    _diagnosisController.clear();
    _timeController.text = '14:30';

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('➕ Новый прием'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _patientNameController,
              decoration: InputDecoration(
                labelText: 'ФИО пациента *',
                prefixIcon: Icon(Icons.person),
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: _timeController,
              decoration: InputDecoration(
                labelText: 'Время (14:30)',
                prefixIcon: Icon(Icons.access_time),
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: _diagnosisController,
              maxLines: 3,
              decoration: InputDecoration(
                labelText: 'Диагноз / Жалобы',
                prefixIcon: Icon(Icons.medical_information),
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Отмена'),
          ),
          ElevatedButton(
            onPressed: () {
              final name = _patientNameController.text.trim();
              if (name.isNotEmpty) {
                setState(() {
                  patients.add({
                    'id': patients.length + 1,
                    'name': name,
                    'phone': '+7 (900) XXX-XX-XX',
                    'visits': [
                      {
                        'date': '14.12.2025',
                        'time': _timeController.text,
                        'diagnosis': _diagnosisController.text,
                      }
                    ],
                  });
                });
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('✅ Прием записан: $name'),
                    backgroundColor: Colors.green,
                  ),
                );
              }
            },
            child: Text('Записать'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
          ),
        ],
      ),
    );
  }

  void _showAddVisitForPatient(int patientIndex) {
    final patient = patients[patientIndex];
    _diagnosisController.clear();
    _timeController.text = '14:30';

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Прием для ${patient['name']}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _timeController,
              decoration: InputDecoration(
                labelText: 'Время приема',
                prefixIcon: Icon(Icons.access_time),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: _diagnosisController,
              maxLines: 3,
              decoration: InputDecoration(
                labelText: 'Диагноз / Рекомендации',
                prefixIcon: Icon(Icons.medical_information),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text('Отмена')),
          ElevatedButton(
            onPressed: () {
              setState(() {
                patient['visits'].add({
                  'date': '14.12.2025',
                  'time': _timeController.text,
                  'diagnosis': _diagnosisController.text,
                });
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('✅ Прием добавлен'), backgroundColor: Colors.green),
              );
            },
            child: Text('Сохранить'),
          ),
        ],
      ),
    );
  }
}
