import 'package:flutter/material.dart';
import 'login_screen.dart';

void main() {
  runApp(MedAnalyticsApp());
}

class MedAnalyticsApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Мед-Аналитика',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: LoginScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}
