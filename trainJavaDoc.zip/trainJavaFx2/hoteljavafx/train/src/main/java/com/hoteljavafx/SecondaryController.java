package com.hoteljavafx;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.fxml.Initializable;

/**
 * Контроллер для вторичного окна приложения.
 */
public class SecondaryController implements Initializable {

    @FXML
    private ComboBox<String> train;

    @FXML
    private ComboBox<String> price;

    /**
     * Метод для выбора поезда и заполнения списка цен.
     *
     * @throws IOException если не удается загрузить FXML файл для вторичного окна.
     */
    @FXML
    private void selectTrain() throws IOException{
        String selectedValue = train.getValue();
        switch(selectedValue){
            case "Стриж":
                price.getItems().clear();
                price.getItems().addAll("950", "1200", "2300");
                break;
            case "Ласточка":
                price.getItems().clear();
                price.getItems().addAll("490", "585", "1300");
                break;
            case "Сап-сан":
                price.getItems().clear();
                price.getItems().addAll("3980", "4800", "5790");
                break;
        }
    }

    /**
     * Метод для переключения на главное окно.
     *
     * @throws IOException если не удается загрузить FXML файл для главного окна.
     */
    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("primary");
    }

    /**
     * Метод для создания действия.
     *
     * @throws IOException если не удается загрузить FXML файл для главного окна.
     */
    @FXML
    private void createAction() throws IOException {
        App.setRoot("primary");
    }


    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        train.getItems().clear();
        train.getItems().addAll("Стриж", "Сап-сан", "Ласточка");
    }

}