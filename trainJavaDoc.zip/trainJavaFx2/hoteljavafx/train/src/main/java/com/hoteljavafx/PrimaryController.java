package com.hoteljavafx;

import java.io.IOException;
import javafx.fxml.FXML;

/**
 * Контроллер для главного окна приложения.
 */
public class PrimaryController {

    /**
     * Метод для добавления поезда.
     *
     * @throws IOException если не удается загрузить FXML файл для вторичного окна.
     */
    @FXML
    private void addTrain() throws IOException {
        App.setRoot("secondary");
    }
}