package com.dance_school_group.dance_school;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DanceSchoolApplicationTests {

	@Test
	void contextLoads() {
	}

}
