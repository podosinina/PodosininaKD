package com.dance_school_group.dance_school.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class managers {

    private Long manager_id;
    private String manager_name;
    private String password;
    private String email;


    protected managers(){
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    public Long getManager_id() {return manager_id;}

    public void setManager_id(Long manager_id) {this.manager_id = manager_id;}

    public String getManager_name() {return manager_name;}

    public void setManager_name(String manager_name) {this.manager_name = manager_name;}

    public String getPassword() {return password;}

    public void setPassword(String password) {this.password = password;}

    public String getEmail() {return email;}

    public void setEmail(String email) {this.email = email;}
}
