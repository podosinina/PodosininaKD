package com.dance_school_group.dance_school.services;

import com.dance_school_group.dance_school.models.clients;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.dance_school_group.dance_school.repositories.clientsRepo;
import java.util.List;

@Service
public class clientsServices {

    @Autowired
    private  clientsRepo clientsRepo;

    public List<clients> listAll(String keyword){
        if(keyword!=null){
            return clientsRepo.search(keyword);
        }
        return clientsRepo.findAll();
    }

    public void save(clients clients){
        clientsRepo.save(clients);
    }

    public void delete(Long client_id){
        clientsRepo.deleteById(client_id);
    }

    public clients getByClientId(Long client_id){
        return clientsRepo.findById(client_id).get();
    }
}
