package com.dance_school_group.dance_school.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class classes {

    private Long class_id;
    private String coach_name;
    private Long group_id;
    private String schedule;
    private String dance_hall;


    protected classes(){

    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    public Long getClass_id() {return class_id;}

    public void setClass_id(Long class_id) {this.class_id = class_id;}

    public String getCoach_name() {return coach_name;}

    public void setCoach_name(String coach_name) {this.coach_name = coach_name;}

    public Long getGroup_id() {return group_id;}

    public void setGroup_id(Long group_id) {this.group_id = group_id;}

    public String getSchedule() {return schedule;}

    public void setSchedule(String schedule) {this.schedule = schedule;}

    public String getDance_hall() {return dance_hall;}

    public void setDance_hall(String dance_hall) {this.dance_hall = dance_hall;}
}
