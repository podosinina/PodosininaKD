package com.dance_school_group.dance_school.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import com.dance_school_group.dance_school.models.applications;
import com.dance_school_group.dance_school.services.applicationsServices;

@Controller
public class applicationController {
    @Autowired
    private  applicationsServices applicationsServices;

    @PostMapping("/application/add")
    public ModelAndView applicationAdd(@ModelAttribute("name") String name, @ModelAttribute("email") String email, @ModelAttribute("phone") String phone, @ModelAttribute("comment") String comment, applications applications){

        applications.setName(name);
        applications.setEmail(email);
        applications.setPhone(phone);
        applications.setComment(comment);

        applicationsServices.save(applications);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("redirect:/");
        return modelAndView;
    }
}
