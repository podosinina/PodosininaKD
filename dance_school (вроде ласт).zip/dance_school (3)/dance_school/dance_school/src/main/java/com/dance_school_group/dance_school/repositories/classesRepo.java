package com.dance_school_group.dance_school.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import  com.dance_school_group.dance_school.models.classes;

import java.util.List;

public interface classesRepo extends JpaRepository<classes, Long> {
    @Query("SELECT p FROM classes p WHERE CONCAT(p.class_id, '', coach_name, '', p.group_id, '', p.schedule, '', p.dance_hall) LIKE %?1%")
    List<classes> search(String keyword);
}
