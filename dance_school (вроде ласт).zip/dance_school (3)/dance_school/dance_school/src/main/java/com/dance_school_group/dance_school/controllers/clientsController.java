package com.dance_school_group.dance_school.controllers;

import org.springframework.ui.Model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import com.dance_school_group.dance_school.models.clients;
import com.dance_school_group.dance_school.services.clientsServices;
import java.util.List;

@Controller
public class clientsController {
    @Autowired
    private clientsServices clientsServices;

    @PostMapping("/clients/add")
    public ModelAndView clientsAdd(@ModelAttribute("client_name") String client_name, @ModelAttribute("client_phone") String client_phone, @ModelAttribute("birth_date") String birth_date, @ModelAttribute("group_id") Long group_id, @ModelAttribute("month_fee") Long month_fee, clients clients) {

        clients.setClient_name(client_name);
        clients.setClient_phone(client_phone);
        clients.setBirth_date(birth_date);
        clients.setGroup_id(group_id);
        clients.setMonth_fee(month_fee);

        clientsServices.save(clients);

        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("redirect:/clientsList.html");
        return modelAndView;
    }

    @RequestMapping("/clientsList.html")
    public ModelAndView showAllTasks(Model model, @Param("keyword") String keyword) {
        List<clients> clientsList = clientsServices.listAll(keyword);
        model.addAttribute("clientsList", clientsList);
        model.addAttribute("keyword", keyword);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("clientsList");
        return modelAndView;
    }

    @RequestMapping("/delete/{client_id}")
    public ModelAndView deleteTask(@PathVariable(name = "client_id") Long client_id){
        clientsServices.delete(client_id);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("redirect:/clientsList.html");
        return modelAndView;
    }

    @RequestMapping("/edit/{client_id}")
    public ModelAndView showEditTask(@PathVariable(name = "client_id") Long client_id){
        ModelAndView modelAndView = new ModelAndView();
        clients clients = clientsServices.getByClientId(client_id);
        modelAndView.setViewName("editClient.html");
        return modelAndView;
    }

    @RequestMapping(value ="/edit", method = RequestMethod.POST)
    public ModelAndView editClient(@ModelAttribute("client") clients clients){
        clientsServices.save(clients);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("redirect:/clientsList.html");
        return modelAndView;}
}
