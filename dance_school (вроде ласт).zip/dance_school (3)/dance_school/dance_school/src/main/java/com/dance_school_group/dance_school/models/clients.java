package com.dance_school_group.dance_school.models;


import jakarta.persistence.*;

@Entity
@Table(name="clients")
public class clients {

    private Long client_id;
    private String client_name;
    private String client_phone;
    private String birth_date;
    private Long group_id;
    private Long month_fee;

    protected clients(){

    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    public Long getClient_id() {
        return client_id;
    }

    public String getClient_name() {
        return client_name;
    }

    public String getClient_phone() {
        return client_phone;
    }

    public String getBirth_date() {
        return birth_date;
    }

    public Long getGroup_id() {
        return group_id;
    }
    public Long getMonth_fee() {
        return month_fee;
    }

    public void setClient_id(Long client_id) {
        this.client_id = client_id;
    }

    public void setClient_name(String client_name) {
        this.client_name = client_name;
    }

    public void setClient_phone(String client_phone) {
        this.client_phone = client_phone;
    }

    public void setBirth_date(String birth_date) {
        this.birth_date = birth_date;
    }

    public void setGroup_id(Long group_id) {
        this.group_id = group_id;
    }
    public void setMonth_fee(Long month_fee) {
        this.month_fee = month_fee;
    }
}
