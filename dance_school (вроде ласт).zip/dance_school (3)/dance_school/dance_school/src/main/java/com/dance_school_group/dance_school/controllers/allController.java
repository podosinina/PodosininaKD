package com.dance_school_group.dance_school.controllers;

import com.dance_school_group.dance_school.services.clientsServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class allController {
    @Autowired clientsServices clientsServices;

    @RequestMapping(value = {"/", "/home.html"})
    public ModelAndView homePage() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("home");
        return modelAndView;}

    @RequestMapping("/dances.html")
    public ModelAndView dancesPage() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("dances");
        return modelAndView;}

    @RequestMapping("/coaches.html")
    public ModelAndView coachesPage() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("coaches");
        return modelAndView;}

    @RequestMapping("/contacts.html")
    public ModelAndView contactsPage() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("contacts");
        return modelAndView;}

    @RequestMapping("/avtorization2.html")
    public ModelAndView avtorizationPage() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("avtorization2");
        return modelAndView;}

    @RequestMapping("/addClients.html")
    public ModelAndView addClientsPage() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("addClients");
        return modelAndView;}
}
