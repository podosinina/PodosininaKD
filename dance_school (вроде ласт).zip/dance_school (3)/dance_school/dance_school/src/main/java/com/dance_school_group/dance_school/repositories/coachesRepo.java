package com.dance_school_group.dance_school.repositories;

import com.dance_school_group.dance_school.models.coaches;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface coachesRepo extends JpaRepository<coaches, Long>{
    @Query("SELECT p FROM coaches p WHERE CONCAT(p.coach_name, '', p.class_direction, '', p.password, '', p.email) LIKE %?1%")
    List<coaches> search(String keyword);
}
