package com.dance_school_group.dance_school.services;

import com.dance_school_group.dance_school.models.classes;
import com.dance_school_group.dance_school.repositories.classesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class classesServices {

    @Autowired
    private classesRepo classesRepo;

    public List<classes> listAll(String keyword){
        if(keyword!=null){
            return classesRepo.search(keyword);
        }
        return classesRepo.findAll();
    }

    public classes getByClassId(Long class_id){
        return classesRepo.findById(class_id).get();
    }
}
