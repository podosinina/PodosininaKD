package com.dance_school_group.dance_school;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DanceSchoolApplication {

	public static void main(String[] args) {
		SpringApplication.run(DanceSchoolApplication.class, args);
	}

}
