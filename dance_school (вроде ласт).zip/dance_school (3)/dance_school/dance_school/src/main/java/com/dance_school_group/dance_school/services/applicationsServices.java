package com.dance_school_group.dance_school.services;
import com.dance_school_group.dance_school.models.applications;
import com.dance_school_group.dance_school.repositories.applicationsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class applicationsServices {

    @Autowired
    private applicationsRepo applicationsRepo;

    public List<applications> listAll(String keyword){
        if(keyword!=null){
            return applicationsRepo.search(keyword);
        }
        return applicationsRepo.findAll();
    }

    public void save(applications applications){
        applicationsRepo.save(applications);}

}
