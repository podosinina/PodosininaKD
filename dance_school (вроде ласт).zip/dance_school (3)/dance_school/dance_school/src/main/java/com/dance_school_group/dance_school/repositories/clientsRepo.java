package com.dance_school_group.dance_school.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import  com.dance_school_group.dance_school.models.clients;


import java.util.List;
public interface clientsRepo extends JpaRepository<clients, Long> {
    @Query("SELECT p FROM clients p WHERE CONCAT(p.client_name, '', p.client_phone, '', p.birth_date, '', p.group_id, '', p.month_fee) LIKE %?1%")
    List<clients> search(String keyword);
}
