package com.dance_school_group.dance_school.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import  com.dance_school_group.dance_school.models.applications;


import java.util.List;
public interface applicationsRepo extends JpaRepository<applications, Long> {
    @Query("SELECT p FROM applications p WHERE CONCAT(p.name, '', p.email, '', p.phone, '', p.comment) LIKE %?1%")
    List<applications> search(String keyword);
}

