package com.dance_school_group.dance_school.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import  com.dance_school_group.dance_school.models.managers;

import java.util.List;

public interface managers_repo {
    @Query("SELECT p FROM managers p WHERE CONCAT(p.manager_name, '', p.password, '', p.email) LIKE %?1%")
    List<managers> search(String keyword);
}
