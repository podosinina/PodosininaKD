package com.dance_school_group.dance_school.models;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class coaches {

    private Long coach_id;
    private String coach_name;
    private String class_direction;
    private String password;
    private String email;


    protected coaches(){

    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    public Long getCoach_id() {
        return coach_id;
    }

    public void setCoach_id(Long coach_id) {
        this.coach_id = coach_id;
    }

    public String getCoach_name() {
        return coach_name;
    }

    public void setCoach_name(String coach_name) {
        this.coach_name = coach_name;
    }

   public String getClass_direction() {
        return class_direction;
    }

    public void setClass_direction(String class_direction) {
        this.class_direction = class_direction;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
