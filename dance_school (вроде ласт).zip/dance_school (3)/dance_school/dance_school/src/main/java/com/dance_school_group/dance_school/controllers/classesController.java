package com.dance_school_group.dance_school.controllers;

import com.dance_school_group.dance_school.models.classes;
import com.dance_school_group.dance_school.services.classesServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import java.util.List;

@Controller
public class classesController {
    @Autowired
    private classesServices classesServices;

    @RequestMapping("/classesList.html")
    public ModelAndView showAllClasses(Model model, @Param("keyword") String keyword) {
        List<classes> classesList = classesServices.listAll(keyword);
        model.addAttribute("classesList", classesList);
        model.addAttribute("keyword", keyword);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("classesList");
        return modelAndView;
    }
}
